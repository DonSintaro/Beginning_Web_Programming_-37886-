


document.getElementById("button").addEventListener("click", function(){makeTable(specials, "specialsTable");


});



document.getElementById("close").addEventListener("click", function(){document.getElementById("specialsTable").innerHTML = "";

});






